opencv_version = "4.9.0.80"
contrib = False
headless = False
rolling = False
ci_build = True